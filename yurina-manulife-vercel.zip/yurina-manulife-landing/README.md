# Yurina — Manulife Consultation Landing Page

Static, mobile-first landing page ready for Vercel.

## Included
- `index.html`: complete landing page, responsive layout, FAQ accordion and WhatsApp form.
- `public/profile.jpg`: add your portrait here (not included yet).
- `vercel.json`: static deployment configuration.

## Personal photo
Save your Instagram profile photo as `public/profile.jpg`.
Recommended: a clear portrait, square or vertical crop, JPG format.

## Deploy to Vercel
1. Extract this ZIP.
2. Create a new GitHub repository and upload the project files (keep `index.html`, `vercel.json`, and `public/` at the repository root).
3. In Vercel, choose **Add New → Project**, import that GitHub repository, and deploy.
4. Framework preset: **Other**. Build command and output directory can remain blank/default for this static project.
5. After deployment, Vercel provides a public URL. You can add a custom domain from the project settings.

## WhatsApp
The form and floating CTA currently open WhatsApp at `+62 812-8182-3162` with a prefilled message.

## Before publishing
- Confirm your preferred display name and professional title.
- Add your actual profile photo to `public/profile.jpg`.
- Verify all wording, licensing/disclosure requirements, and product descriptions with your Manulife agency/compliance team.
- Replace or add verified credentials/experience only if you want them displayed. No invented metrics are used in this version.
